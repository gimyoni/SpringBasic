package kr.hs.study.beans;

public class TestBean implements Test {

	public TestBean() {
		System.out.println("TestBean의 생성자");
	}
	
	public void method1() {
		System.out.println("TestBean의 메서드");

	}

}
