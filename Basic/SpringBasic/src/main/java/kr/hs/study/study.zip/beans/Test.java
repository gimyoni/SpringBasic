package kr.hs.study.beans;

public interface Test {
	public void method1();
}
